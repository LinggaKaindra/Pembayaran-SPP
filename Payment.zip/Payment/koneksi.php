<?php

$host = "localhost";
$user = "root";
$passdatabase = "";
$select_db = "espepe";

$koneksi = mysqli_connect($host, $user, $passdatabase, $select_db);

?>