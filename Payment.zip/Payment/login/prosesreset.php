<?php
session_start();

include "../koneksi.php";

$email = $_POST['email'];