#Project Pembayaran UKT

tb_user
untuk menampung data petugas dan admin

tb student
untuk menampung data siswa

tb academic year 
untuk menampung data tahun ajaran dan semester berapa

tb payment methods
untuk menampung data metode pembayaran yang dilakukan

tb programs
untuk menampung data program studi alias fakultas

ukt
untuk menampung data pembayaran yang harus dilakukan (seperti order)

payments
untuk menampung status pembayaran / history dari ukt tersebut